package com.lineal.regression.app.dto

// DTO que representa la respuesta de la regresión lineal
// Contiene los resultados calculados por el servicio
data class RegressionResponse(
    val slope: Double,               // Pendiente de la recta (m)
    val intercept: Double,           // Intercepto de la recta (b)
    val equation: String,            // Ecuación de la recta como texto (y = mx + b)
    val predicted: List<Double>      // Lista de valores y predichos para cada x enviada
)
