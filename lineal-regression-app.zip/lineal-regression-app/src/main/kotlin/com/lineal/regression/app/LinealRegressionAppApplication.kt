package com.lineal.regression.app

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class LinealRegressionAppApplication

fun main(args: Array<String>) {
	runApplication<LinealRegressionAppApplication>(*args)
}
