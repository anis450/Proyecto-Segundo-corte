package com.lineal.regression.app.dto

// DTO que representa un punto en 2D para la regresión lineal
data class PointDto(
    val x: Double?, // Valor de la coordenada X; puede ser nulo, se valida en el servicio
    val y: Double?  // Valor de la coordenada Y; puede ser nulo, se valida en el servicio
)
