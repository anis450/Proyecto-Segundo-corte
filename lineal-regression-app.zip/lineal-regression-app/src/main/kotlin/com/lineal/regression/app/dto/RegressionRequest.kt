package com.lineal.regression.app.dto

// DTO que representa la petición de regresión lineal
// Contiene una lista de puntos (x, y) que se usarán para el cálculo
data class RegressionRequest(
    val points: List<PointDto>? = null, // Lista de puntos; puede ser nula si no se envían datos
)
