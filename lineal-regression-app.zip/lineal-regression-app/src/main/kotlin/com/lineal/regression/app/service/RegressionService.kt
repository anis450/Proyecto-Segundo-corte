package com.lineal.regression.app.service

import com.lineal.regression.app.dto.RegressionRequest
import com.lineal.regression.app.dto.RegressionResponse
import org.springframework.stereotype.Service
import kotlin.math.pow
import kotlin.math.round

// Servicio que realiza el cálculo de regresión lineal
@Service
class RegressionService {

    fun compute(request: RegressionRequest): RegressionResponse {
        val xs = mutableListOf<Double>()
        val ys = mutableListOf<Double>()

        // Validamos que los puntos no sean nulos y los separamos en listas de x y y
        if (!request.points.isNullOrEmpty()) {
            for (p in request.points) {
                if (p.x == null || p.y == null) {
                    throw IllegalArgumentException("Points must not contain nulls.")
                }
                xs.add(p.x)
                ys.add(p.y)
            }
        }

        val n = xs.size.toDouble()
        val sumX = xs.sum()
        val sumY = ys.sum()
        val sumXY = xs.zip(ys).sumOf { it.first * it.second }
        val sumX2 = xs.sumOf { it * it }

        // Calculamos el denominador de la fórmula de regresión lineal
        val denominator = n * sumX2 - sumX * sumX
        if (denominator == 0.0) {
            throw IllegalArgumentException("Denominator is zero — cannot compute a unique regression line (maybe all x are equal).")
        }

        // Calculamos pendiente (m) e intercepto (b)
        val m = (n * sumXY - sumX * sumY) / denominator
        val b = (sumY - m * sumX) / n

        // Calculamos los valores predichos
        val predicted = xs.map { x -> m * x + b }

        // Función para redondear números a cierta cantidad de decimales
        fun roundTo(v: Double, decimals: Int = 6): Double {
            val factor = 10.0.pow(decimals)
            return round(v * factor) / factor
        }

        // Redondeamos pendiente, intercepto y valores predichos
        val slopeRounded = roundTo(m, 6)
        val interceptRounded = roundTo(b, 6)
        val predictedRounded = predicted.map { roundTo(it, 6) }

        // Construimos la ecuación como string
        val equation = "y = ${slopeRounded}x + ${interceptRounded}"

        // Retornamos la respuesta con los resultados
        return RegressionResponse(
            slope = slopeRounded,
            intercept = interceptRounded,
            equation = equation,
            predicted = predictedRounded
        )
    }

    // Extensiones para usar pow de manera cómoda
    private fun Double.Companion.pow(p: Int) = Math.pow(10.0, p.toDouble())
    private fun Double.pow(p: Int) = Math.pow(this, p.toDouble())
}
