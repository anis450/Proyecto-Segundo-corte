package com.lineal.regression.app.exception

import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.ControllerAdvice
import org.springframework.web.bind.annotation.ExceptionHandler

// DTO simple para enviar mensajes de error al cliente
data class ErrorResponse(
    val error: String,          // Tipo de error
    val details: String? = null // Mensaje adicional o detalles del error
)

// Clase que maneja excepciones de forma global en la aplicación
@ControllerAdvice
class GlobalExceptionHandler {

    // Maneja errores de tipo IllegalArgumentException (ej. puntos nulos o inválidos)
    @ExceptionHandler(IllegalArgumentException::class)
    fun handleBadRequest(ex: IllegalArgumentException): ResponseEntity<ErrorResponse> {
        return ResponseEntity(
            ErrorResponse("Bad Request", ex.message),
            HttpStatus.BAD_REQUEST
        )
    }

    // Maneja cualquier otra excepción no controlada
    @ExceptionHandler(Exception::class)
    fun handleGeneric(ex: Exception): ResponseEntity<ErrorResponse> {
        return ResponseEntity(
            ErrorResponse("Internal Server Error", ex.message),
            HttpStatus.INTERNAL_SERVER_ERROR
        )
    }
}
