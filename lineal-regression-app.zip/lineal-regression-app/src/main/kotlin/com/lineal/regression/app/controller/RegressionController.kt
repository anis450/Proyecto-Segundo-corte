package com.lineal.regression.app.controller

import com.lineal.regression.app.dto.RegressionRequest
import com.lineal.regression.app.dto.RegressionResponse
import com.lineal.regression.app.service.RegressionService
import jakarta.validation.Valid
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

// Controlador REST que expone el endpoint para calcular regresión lineal
@RestController
@RequestMapping("/api/regression")
class RegressionController(
    private val regressionService: RegressionService // Servicio que realiza la lógica de la regresión
) {

    // Endpoint POST que recibe los puntos y devuelve la regresión
    @PostMapping
    fun compute(@RequestBody @Valid request: RegressionRequest): ResponseEntity<RegressionResponse> {
        // Llamamos al servicio para calcular la regresión
        val result = regressionService.compute(request)
        // Retornamos el resultado con código HTTP 200 OK
        return ResponseEntity(result, HttpStatus.OK)
    }
}
