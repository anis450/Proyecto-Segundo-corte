package com.lineal.regression.app.service

import com.lineal.regression.app.dto.PointDto
import com.lineal.regression.app.dto.RegressionRequest
import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.assertThrows

class RegressionServiceTest {

    private val service = RegressionService()

    @Test
    fun `should compute regression correctly`() {
        // given
        val points = listOf(
            PointDto(1.0, 2.0),
            PointDto(2.0, 4.0),
            PointDto(3.0, 5.0),
            PointDto(4.0, 4.0),
            PointDto(5.0, 5.0)
        )
        val request = RegressionRequest(points = points)

        // when
        val result = service.compute(request)

        // then
        assertNotNull(result)
        assertEquals("y = ${result.slope}x + ${result.intercept}", result.equation)
    }

    @Test
    fun `should throw error when points contain null values`() {
        // given
        val points = listOf(
            PointDto(1.0, null),
            PointDto(2.0, 3.0)
        )
        val request = RegressionRequest(points = points)

        // when + then
        val ex = assertThrows<IllegalArgumentException> {
            service.compute(request)
        }
        assertTrue(ex.message!!.contains("Points must not contain nulls"))
    }

    @Test
    fun `should throw error when all x values are equal`() {
        // given
        val points = listOf(
            PointDto(2.0, 3.0),
            PointDto(2.0, 5.0),
            PointDto(2.0, 8.0)
        )
        val request = RegressionRequest(points = points)

        // when + then
        val ex = assertThrows<IllegalArgumentException> {
            service.compute(request)
        }
        assertTrue(ex.message!!.contains("Denominator is zero"))
    }
}
