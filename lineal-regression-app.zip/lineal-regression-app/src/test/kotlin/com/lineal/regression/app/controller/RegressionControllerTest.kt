package com.lineal.regression.app.controller

import com.lineal.regression.app.dto.PointDto
import com.lineal.regression.app.dto.RegressionRequest
import com.lineal.regression.app.dto.RegressionResponse
import com.lineal.regression.app.service.RegressionService
import org.junit.jupiter.api.Test
import org.mockito.Mockito
import kotlin.test.assertEquals

class RegressionControllerUnitTest {

    private val regressionService = Mockito.mock(RegressionService::class.java)
    private val controller = RegressionController(regressionService)

    @Test
    fun `compute should return regression result`() {
        val request = RegressionRequest(
            points = listOf(
                PointDto(1.0, 2.0),
                PointDto(2.0, 3.0),
                PointDto(3.0, 4.0)
            )
        )

        val expected = RegressionResponse(
            slope = 1.0,
            intercept = 1.0,
            equation = "y = 1.0x + 1.0",
            predicted = listOf(2.0, 3.0, 4.0)
        )

        Mockito.`when`(regressionService.compute(request)).thenReturn(expected)

        val response = controller.compute(request)

        assertEquals(200, response.statusCodeValue)
        assertEquals(expected, response.body)
    }
}
