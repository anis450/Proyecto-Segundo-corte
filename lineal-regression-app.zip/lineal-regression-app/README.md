# Aplicación de Regresión Lineal Simple

Esta aplicación permite calcular la **línea de regresión lineal** a partir de un conjunto de puntos `(x, y)`.  
Incluye un backend en **Kotlin + Spring Boot** y un frontend sencillo en **HTML/JS** con visualización de resultados mediante **Chart.js**.

---

## Estructura del Proyecto

### Backend

- **Controller:**  
  `RegressionController`  
  Expone un endpoint POST `/api/regression` que recibe los puntos y devuelve los resultados de la regresión.

- **Service:**  
  `RegressionService`  
  Calcula la regresión lineal simple, pendiente (m), intercepto (b), valores predichos y la ecuación en formato texto.

- **DTOs:**
    - `PointDto`: representa un punto `(x, y)`.
    - `RegressionRequest`: lista de puntos para enviar al backend.
    - `RegressionResponse`: resultados de la regresión: pendiente, intercepto, ecuación y valores predichos.

- **Manejo de errores:**  
  `GlobalExceptionHandler` maneja errores globalmente y devuelve mensajes claros al cliente.

---

### Frontend

- **HTML/JS:**
    - Permite ingresar puntos `(x, y)` manualmente o cargar un ejemplo.
    - Calcula la regresión enviando los datos al backend.
    - Muestra la **ecuación, pendiente, intercepto** y un gráfico interactivo con los puntos y la línea de regresión.
    - Utiliza **Chart.js** para visualización y **SweetAlert2** para alertas y notificaciones.

---

## 🚀 Cómo usar la aplicación

### 1. Iniciar el backend

1. Asegúrate de tener **Java 17+** y **Maven** instalados.
2. Compila y ejecuta el proyecto Spring Boot:
   ```bash
   mvn clean install
   mvn spring-boot:run
