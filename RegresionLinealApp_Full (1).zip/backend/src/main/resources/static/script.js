const sendBtn = document.getElementById('send');
const clearBtn = document.getElementById('clear');
const output = document.getElementById('output');
const pointsArea = document.getElementById('points');
let chart = null;

function showMessage(msg) {
  output.textContent = msg;
}

function validateJSON(text) {
  try {
    const parsed = JSON.parse(text);
    if (!Array.isArray(parsed)) throw new Error('Debe ser una lista de puntos');
    for (const p of parsed) {
      if (typeof p.x !== 'number' || typeof p.y !== 'number') throw new Error('Cada punto debe tener x e y numéricos');
      if (!isFinite(p.x) || !isFinite(p.y)) throw new Error('Valores deben ser finitos');
    }
    return parsed;
  } catch (e) {
    throw e;
  }
}

async function postPoints(points) {
  const res = await fetch('/api/regresion', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify(points)
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({error:res.statusText}));
    throw new Error(err.error || 'Error en la API');
  }
  return await res.json();
}

function plot(original, adjusted) {
  const ctx = document.getElementById('chart').getContext('2d');
  const origData = original.map(p => ({x:p.x,y:p.y}));
  const lineData = adjusted.map(p => ({x:p.x,y:p.y}));

  if (chart) chart.destroy();

  chart = new Chart(ctx, {
    type: 'scatter',
    data: {
      datasets: [
        { label: 'Datos originales', data: origData, pointRadius:4 },
        { label: 'Línea ajustada', data: lineData, showLine:true, fill:false, tension:0, pointRadius:0 }
      ]
    },
    options: {
      scales: { x: { type: 'linear', position: 'bottom' } }
    }
  });
}

sendBtn.addEventListener('click', async () => {
  try {
    showMessage('Enviando datos...');
    const parsed = validateJSON(pointsArea.value);
    if (parsed.length < 2) throw new Error('Se necesitan al menos 2 puntos');

    const res = await postPoints(parsed);
    const txt = `Ecuación: y = ${res.slope.toFixed(4)}x + ${res.intercept.toFixed(4)}\nR² = ${res.r2.toFixed(4)}\nPuntos usados = ${res.usedPoints}, eliminados = ${res.removedPoints}`;
    showMessage(txt + '\n\nAdjusted Data:\n' + JSON.stringify(res.adjustedData, null, 2));

    plot(parsed, res.adjustedData);
  } catch (e) {
    showMessage('Error: ' + e.message);
  }
});

clearBtn.addEventListener('click', () => {
  pointsArea.value = '[]';
  showMessage('Esperando acción...');
  if (chart) { chart.destroy(); chart = null; }
});
