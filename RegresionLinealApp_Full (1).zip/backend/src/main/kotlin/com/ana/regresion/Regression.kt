package com.ana.regresion

import kotlin.math.*
import io.ktor.server.plugins.*

data class DataPoint(val x: Double, val y: Double)

data class RegressionResult(
    val slope: Double,
    val intercept: Double,
    val r2: Double,
    val adjustedData: List<DataPoint>,
    val usedPoints: Int,
    val removedPoints: Int
)

fun performLinearRegression(rawPoints: List<DataPoint>?): RegressionResult {
    val pts = rawPoints ?: throw BadRequestException("No se recibieron puntos")

    val finite = pts.filter { it.x.isFinite() && it.y.isFinite() }
    val unique = finite.distinct()

    if (unique.size < 2) throw BadRequestException("Se necesitan al menos 2 puntos válidos para la regresión")

    val n = unique.size
    val sumX = unique.sumOf { it.x }
    val sumY = unique.sumOf { it.y }
    val meanX = sumX / n
    val meanY = sumY / n

    val sumXY = unique.sumOf { it.x * it.y }
    val sumX2 = unique.sumOf { it.x * it.x }
    val denom = (n * sumX2 - sumX * sumX)
    val slopeInit = if (denom == 0.0) 0.0 else (n * sumXY - sumX * sumY) / denom
    val interceptInit = meanY - slopeInit * meanX

    val residuals = unique.map { abs(it.y - (slopeInit * it.x + interceptInit)) }

    val medRes = residuals.sorted()[residuals.size / 2]
    val mad = residuals.map { abs(it - medRes) }.sorted()[residuals.size / 2]
    val threshold = medRes + 3.0 * (if (mad == 0.0) 1.4826 * medRes.coerceAtLeast(1.0) else 1.4826 * mad)

    val (kept, removed) = unique.partition { abs(it.y - (slopeInit * it.x + interceptInit)) <= threshold }

    val usedPoints = kept.size
    val removedPoints = unique.size - usedPoints

    if (usedPoints < 2) throw BadRequestException("Después de filtrar outliers no hay suficientes puntos válidos")

    val n2 = usedPoints
    val sumX2k = kept.sumOf { it.x * it.x }
    val sumXk = kept.sumOf { it.x }
    val sumYk = kept.sumOf { it.y }
    val sumXYk = kept.sumOf { it.x * it.y }

    val denom2 = (n2 * sumX2k - sumXk * sumXk)
    val slope = if (denom2 == 0.0) 0.0 else (n2 * sumXYk - sumXk * sumYk) / denom2
    val intercept = (sumYk - slope * sumXk) / n2

    val meanYk = sumYk / n2
    val ssTotal = kept.sumOf { (it.y - meanYk) * (it.y - meanYk) }
    val ssResidual = kept.sumOf { val pred = slope * it.x + intercept; (it.y - pred) * (it.y - pred) }
    val r2 = if (ssTotal == 0.0) 1.0 else 1.0 - ssResidual / ssTotal

    val adjusted = kept.map { DataPoint(it.x, slope * it.x + intercept) }

    return RegressionResult(slope, intercept, r2, adjusted, usedPoints, removedPoints)
}
