package com.ana.regresion

import io.ktor.server.engine.*
import io.ktor.server.netty.*
import io.ktor.server.application.*
import io.ktor.server.plugins.contentnegotiation.*
import io.ktor.serialization.gson.*
import io.ktor.server.routing.*
import io.ktor.http.content.*

fun main() {
    embeddedServer(Netty, port = 8080) {
        configureSerialization()
        configureRouting()
    }.start(wait = true)
}

fun Application.configureSerialization() {
    install(ContentNegotiation) {
        gson {
            setPrettyPrinting()
        }
    }
}

fun Application.configureRouting() {
    routing {
        static("/") {
            resources("static")
            defaultResource("index.html", "static")
        }
        apiRoutes()
    }
}
