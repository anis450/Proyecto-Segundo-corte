package com.ana.regresion

import io.ktor.server.routing.*
import io.ktor.server.application.*
import io.ktor.server.request.*
import io.ktor.server.response.*
import io.ktor.http.*
import io.ktor.server.plugins.*

fun Route.apiRoutes() {
    route("/api") {
        get("/ping") {
            call.respond(mapOf("status" to "ok", "msg" to "API de regresión lista"))
        }

        post("/regresion") {
            try {
                val points = call.receive<List<DataPoint>>()
                val result = performLinearRegression(points)
                call.respond(HttpStatusCode.OK, result)
            } catch (e: BadRequestException) {
                call.respond(HttpStatusCode.BadRequest, mapOf("error" to (e.message ?: "input inválido")))
            } catch (e: ContentTransformationException) {
                call.respond(HttpStatusCode.BadRequest, mapOf("error" to "Formato JSON inválido. Asegúrate de enviar una lista de objetos con x e y"))
            } catch (e: Exception) {
                call.respond(HttpStatusCode.InternalServerError, mapOf("error" to (e.message ?: "Error interno")))
            }
        }
    }
}
