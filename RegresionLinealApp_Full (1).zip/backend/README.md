        Proyecto: RegresionLinealApp (Ktor)

        Contiene backend Ktor y frontend estático.


        Nota: gradle-wrapper.jar no está incluido. Para usar el Gradle Wrapper, genere o descargue gradle-wrapper.jar.


        Ejecutar con Gradle instalado:
  cd backend
  gradle run

Ejecutar con wrapper (si gradle-wrapper.jar está presente):
  cd backend
  Windows: gradlew.bat run
  Linux/Mac: ./gradlew run
