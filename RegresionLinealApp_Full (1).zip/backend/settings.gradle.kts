rootProject.name = "RegresionLinealApp"
