Proyecto RegresionLinealApp - backend Ktor + frontend estático.
